$( document ).ready(function() {

  	$('body').awesomeCursor('camera-retro');
	console.log("you are awesome");
});